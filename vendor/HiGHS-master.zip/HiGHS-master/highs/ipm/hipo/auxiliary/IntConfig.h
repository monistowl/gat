#ifndef HIPO_INT_CONFIG_H
#define HIPO_INT_CONFIG_H

#include "util/HighsInt.h"
#include "lp_data/HConst.h"

namespace hipo {

typedef HighsInt Int;

}

#endif