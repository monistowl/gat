#define SCIP_BUILDFLAGS "n/a"
