---
title:  "Welcome to the new COIN-OR Documentation site"
categories: welcome
permalink: welcome-to-coin-or-documentation.html
tags: [news]
---

Welcome to the new COIN-OR documentation site! We are just getting started, so
hopefully, this site will grow more in the future. Keep checking back!

{% include links.html %}
