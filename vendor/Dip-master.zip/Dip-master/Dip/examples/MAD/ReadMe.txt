http://elib.zib.de/pub/Packages/mp-testdata/madlib/index.html
http://www.zib.de/Publications/Reports/SC-97-14.pdf
http://www.zib.de/Publications/Reports/SC-97-15.pdf