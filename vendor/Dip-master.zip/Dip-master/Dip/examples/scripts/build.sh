cd ../../../$1/Dip/examples/MMKP
make clean
make
cd ../ATM
make clean
make
cd ../MILPBlock
make clean
make
cd ../GAP
make clean
make

