atm_rand.tgz is now at http://coral.ie.lehigh.edu/~magh/decomp/
