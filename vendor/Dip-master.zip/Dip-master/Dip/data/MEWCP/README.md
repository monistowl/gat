For instances, see

https://github.com/tkralphs/DecompLib/tree/master/maxclique




