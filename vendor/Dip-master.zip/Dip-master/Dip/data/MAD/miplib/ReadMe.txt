PRIMAL.tar.gz is now at http://coral.ie.lehigh.edu/~magh/decomp/
