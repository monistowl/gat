cd equipart
tar -zxvf NN.tar.gz
cd ../miplib
tar -zxvf PRIMAL.tar.gz
cd ../miplibT
tar -zxvf TRANS.tar.gz
cd ../netlib
tar -zxvf NET.tar.gz
cd ../steiner
tar -zxvf PST.tar.gz
