For instances, see

https://github.com/tkralphs/DecompLib/tree/master/AP3

Download tarballs at

https://github.com/tkralphs/DecompLib/blob/master/AP3/ap3.tgz
https://github.com/tkralphs/DecompLib/blob/master/AP3/Salzman.tgz


