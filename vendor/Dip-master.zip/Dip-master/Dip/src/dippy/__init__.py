from __future__ import absolute_import
import sys

try:
    import path
except ImportError:
    pass

from .dippy import *

