ITEMS  = [1, 2, 3, 4, 5]
volume = {1: 2, 2: 5, 3: 3, 4: 7, 5: 2}
capacity = 8
