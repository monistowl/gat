wget http://coral.ie.lehigh.edu/~jiadongwang/miplib2010-1.0.4.tgz

tar -xvzf miplib2010-1.0.4.tgz