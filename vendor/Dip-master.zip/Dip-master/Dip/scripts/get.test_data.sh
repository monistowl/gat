cd ../../Data/Sample

wget http://coral.ie.lehigh.edu/~jiadongwang/DIP/make_test/atm_5_10_1.block

wget http://coral.ie.lehigh.edu/~jiadongwang/DIP/make_test/atm_5_10_1.mps

wget http://coral.ie.lehigh.edu/~jiadongwang/DIP/make_test/retail3.mps

wget http://coral.ie.lehigh.edu/~jiadongwang/DIP/make_test/retail3.block

wget http://coral.ie.lehigh.edu/~jiadongwang/DIP/make_test/wedding_16.mps

wget http://coral.ie.lehigh.edu/~jiadongwang/DIP/make_test/wedding_16.block