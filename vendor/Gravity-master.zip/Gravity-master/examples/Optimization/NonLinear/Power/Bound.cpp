//
//  Bound.cpp
//  Gravity++
//
//  Created by Hassan on 4/02/2015.

//

#include "Bound.h"

Bound::Bound():min(0.0), max(0.0){
}
