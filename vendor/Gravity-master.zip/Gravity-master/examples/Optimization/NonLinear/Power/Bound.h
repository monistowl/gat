//
//  Bound.h
//  PowerTools++
//
//  Created by Hassan on 4/02/2015.
//  Copyright (c) 2015 NICTA. All rights reserved.
//

#ifndef Bound_h
#define Bound_h

#include <stdio.h>
#include <math.h>

class Bound {

public:
    /** Lower bound */
    double min;
    /** Upper bound */
    double max;
    
    Bound();
    
    
};
#endif /* defined(__PowerTools____Bound__) */
