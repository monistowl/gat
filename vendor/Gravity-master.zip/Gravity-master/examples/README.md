

## EXAMPLES

Mathematical Optimization models can be found under [Optimization](https://github.com/coin-or/Gravity/blob/master/examples/Optimization).

Machine Learning models can be found under [MachineLearning](https://github.com/coin-or/Gravity/blob/master/examples/MachineLearning).

For an overview on Gravity's basic features check [Gravity_test.cpp](https://github.com/coin-or/Gravity/blob/master/examples/Gravity_test.cpp) which is also used for unit testing.
