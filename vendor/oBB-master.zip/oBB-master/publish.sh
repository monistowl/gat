# Register
python setup.py register

# Publish Package
python setup.py sdist upload

# Publish Docs
python setup.py upload_docs --upload-dir=docs/html
