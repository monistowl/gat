mpiexec -n 4 python -W ignore::DeprecationWarning sins.py T1 1 1 c 10 0 a
