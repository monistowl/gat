# Global variables
N = 0
D = 0
a = 0
x = 0
tl = 0
tl2 = 0
