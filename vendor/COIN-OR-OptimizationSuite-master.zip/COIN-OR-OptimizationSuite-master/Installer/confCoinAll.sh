export CXXFLAGS="-O3"
export CFLAGS="-O3"
export LDFLAGS="-static-libgcc -static"
./configure --prefix=/home/haroldo/dev/coinallinst/lin64/ --enable-static

