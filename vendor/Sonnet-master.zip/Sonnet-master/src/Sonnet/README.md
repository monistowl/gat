Sonnet
------

The Sonnet assembly ('library', 'assembly' and 'project' used as if synonymous) 
is the other half of the Sonnet project. 

SonnetWrapper (C++/CLI) makes the .NET link to the native C++ COIN libraries, 
and Sonnet (C#) offers the modelling API.

See also INSTALL.