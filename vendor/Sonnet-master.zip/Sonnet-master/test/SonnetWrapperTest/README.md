About SonnetWrapperTest
-----------------------

SonnetWrapperTest is merely a sandbox project for SonnetWrapper and native COIN-OR calls,
since stepping into the native C++ from the C# projects of Sonnet is not possible (?)

This is NOT a structure test project.