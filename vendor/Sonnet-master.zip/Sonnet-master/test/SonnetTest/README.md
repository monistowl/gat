About SonnetTest
----------------

SonnetTest performs various tests on functionality of Sonnet, repeated for all implemented OsiSolverInterface types.

brandy.mps is available via
https://projects.coin-or.org/svn/Data/Sample/releases/1.2.0/brandy.mps

egout.mps is part of the Cgl test data:
https://projects.coin-or.org/svn/Cgl/trunk/Cgl/test/CglTestData/egout.mps

See also INSTALL.