// Copyright (C) 2007, International Business Machines
// Corporation and others.  All Rights Reserved.
// This code is licensed under the terms of the Eclipse Public License (EPL).

#ifndef COIN_HAS_CBC
#define COIN_HAS_CBC
#endif
#ifndef COIN_HAS_CLP
#define COIN_HAS_CLP
#endif
#include "CbcModel.hpp"
#include "CbcOrClpParam.cpp"

/* vi: softtabstop=2 shiftwidth=2 expandtab tabstop=2
*/
