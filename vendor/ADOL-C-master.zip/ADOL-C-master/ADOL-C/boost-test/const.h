#ifndef CONST_H
#define CONST_H

const double tol = 1e-8;

#endif
