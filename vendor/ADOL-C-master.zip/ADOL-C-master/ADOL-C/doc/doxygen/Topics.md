@defgroup TapeLess Tape-less forward mode
@brief Interfaces for tape-less forward mode AD

@defgroup TapeForward Tape-based forward mode
@brief Interfaces for tape-base forward mode AD

@defgroup TapeBackward Tape-based backward mode
@brief Interfaces for tape-base backward mode AD

