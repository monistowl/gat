dyn.load(paste("R/adolc", .Platform$dynlib.ext, sep=""))
source("R/adolc.R")
cacheMetaData(1)

