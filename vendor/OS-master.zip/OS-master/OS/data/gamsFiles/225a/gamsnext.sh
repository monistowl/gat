gmshldus.run /Users/kmartin/Documents/files/coursework/qa751/testProblems/parinc/225a/ /Users/kmartin/Documents/files/coursework/qa751/testProblems/parinc/ 10 0
