cuOpt-LP - mps parser and data model
