cuOpt - GPU Combinatorial Optimization
