cuOpt Microserver - GPU Combinatorial Optimization
