Place holder for docker context.
