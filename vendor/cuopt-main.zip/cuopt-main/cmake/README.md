# Cmake for RAPIDS configuration

This directory contains the Cmake files for the RAPIDS configuration.
