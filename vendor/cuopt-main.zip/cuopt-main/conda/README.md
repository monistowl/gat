# Conda Recipes and Environment

This directory contains the conda recipes for the cuOpt packages which are used to build the conda packages in CI.

Along with that, it also contains the environment files which is used to create the conda environment for the development of cuOpt and CI testing.
