========================================
cuOpt Open-API Reference - Swagger
========================================

.. swagger-plugin:: cuopt_spec.yaml
   :id: cuopt-api
