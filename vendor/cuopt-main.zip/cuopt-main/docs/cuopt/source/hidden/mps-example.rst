~~~~~~~~~~~~~~~~~~~~~~~~
cuOpt MPS Parser Example
~~~~~~~~~~~~~~~~~~~~~~~~


Example
-------

.. code-block:: python
    :linenos:

    import cuopt_mps_parser
    x = cuopt_mps_parser.ParseMps('good-mps-1.mps')
