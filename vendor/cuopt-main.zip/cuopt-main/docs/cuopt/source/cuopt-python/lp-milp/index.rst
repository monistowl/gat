=======================================================
Linear Programming and Mixed Integer Linear Programming
=======================================================

This section contains details on the cuOpt linear programming and mixed integer linear programming Python API.

.. toctree::
   :maxdepth: 3
   :caption: LP and MILP
   :name: LP and MILP
   :titlesonly:

   lp-milp-api.rst
   lp-milp-examples.rst
