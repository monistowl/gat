=================================
cuOpt License
=================================

.. literalinclude:: ../../../LICENSE
   :language: text
