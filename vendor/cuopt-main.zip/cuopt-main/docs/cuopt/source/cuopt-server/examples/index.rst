========================================
Examples
========================================

This section contains examples on how to use the cuOpt server using the client.

.. toctree::
   :maxdepth: 3
   :caption: Examples Overview
   :name: Examples Overview
   :titlesonly:

   lp-examples.rst
   milp-examples.rst
   routing-examples.rst
