========================================
CSP Guides
========================================

This section contains guides on how to use the cuOpt server in different cloud providers.

.. toctree::
   :maxdepth: 3
   :caption: CSP Guides Overview
   :name: CSP Guides Overview
   :titlesonly:

   csp-azure.rst
   csp-aws.rst
