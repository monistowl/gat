========================================
Server API
========================================

This section contains details on Server options supported and open-api specification for the server.

.. toctree::
   :maxdepth: 3
   :caption: Server API Overview
   :name: Server API Overview
   :titlesonly:

   server-cli.rst
   ../../open-api.rst
   ../../lp-milp-settings.rst
