
========================================
cuOpt Server CLI
========================================

This section describes the cuOpt Server CLI, which is a command-line interface for the cuOpt Server. Most of these options can also be configured using environment variables.

.. literalinclude:: server-cli-help.txt
    :language: shell
    :linenos:
