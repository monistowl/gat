========================================
Client API Overview
========================================

Client is used to communicate with the cuOpt server. More details can be found below.

.. toctree::
   :maxdepth: 3
   :caption: Client API Overview
   :name: Client API Overview
   :titlesonly:

   sh-cli-api.rst
   sh-cli-build.rst
