# Notebooks

This directory contains the sample notebooks for the cuOpt project.

Users can find more advanced examples in the [cuOpt Examples](https://github.com/nvidia/cuopt-examples) repository.
