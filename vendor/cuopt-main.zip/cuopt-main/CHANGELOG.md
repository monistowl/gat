# cuOpt 25.05.00 (Date TBD)

## 🚨 Breaking Changes

## 🐛 Bug Fixes

## 📖 Documentation

## 🚀 New Features

## 🛠️ Improvements

## 🐛 Bug Fixes
