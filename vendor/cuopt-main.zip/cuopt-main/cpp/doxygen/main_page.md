# libcuopt

libcuopt is a C++ GPU accelerated optimization library with a focus on the Vehicle Routing Problem (VRP), Linear Programming (LP), and Mixed Integer Linear Programming (MILP).
