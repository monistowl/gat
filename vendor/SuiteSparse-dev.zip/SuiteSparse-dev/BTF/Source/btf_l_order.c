//------------------------------------------------------------------------------
// BTF/Source/btf_l_order.c: int64_t version of btf_order
//------------------------------------------------------------------------------

// BTF, Copyright (c) 2004-2022, University of Florida.  All Rights Reserved.
// Author: Timothy A. Davis.
// SPDX-License-Identifier: LGPL-2.1+

//------------------------------------------------------------------------------

#define DLONG
#include "btf_order.c"

