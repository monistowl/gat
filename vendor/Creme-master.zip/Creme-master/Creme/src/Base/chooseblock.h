/*
 * Name:    chooseblock.h
 * Author:  Pietro Belotti
 *
 * This code is published under the Eclipse Public License (EPL).
 * See http://www.eclipse.org/legal/epl-v10.html
 *
 */

#ifndef CHOOSEBLOCK_H
#define CHOOSEBLOCK_H

void choose_block (sparseLP *, int *, char *, int, int, double *, double);

#endif
