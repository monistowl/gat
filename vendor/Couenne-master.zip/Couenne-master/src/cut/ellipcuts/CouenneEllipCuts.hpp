#ifndef CouenneEllipCuts_hpp
#define CouenneEllipCuts_hpp

namespace Couenne {

}

#endif
