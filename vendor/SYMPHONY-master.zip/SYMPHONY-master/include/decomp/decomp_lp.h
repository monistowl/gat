#ifndef _DECOMP_LP_H
#define _DECOMP_LP_H

#include<sym_lp_solver.h>

void load_decomp_lp PROTO((LPdata *lp_data));
void unload_decomp_lp PROTO((LPdata *lp_data));

#endif
